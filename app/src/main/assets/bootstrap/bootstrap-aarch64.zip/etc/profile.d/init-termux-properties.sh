if [ ! -f /data/user/0/com.dc.andagent/files/home/.config/termux/termux.properties ] && [ ! -e /data/user/0/com.dc.andagent/files/home/.termux/termux.properties ]; then
	mkdir -p /data/user/0/com.dc.andagent/files/home/.termux
	cp /data/user/0/com.dc.andagent/files/usr/share/examples/termux/termux.properties /data/user/0/com.dc.andagent/files/home/.termux/
fi
