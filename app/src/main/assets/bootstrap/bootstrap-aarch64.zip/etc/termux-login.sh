##
## This script is sourced by /data/user/0/io.nous.andagent/files/usr/bin/login before executing shell.
##
