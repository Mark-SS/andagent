##
## This script is sourced by /data/user/0/com.dc.andagent/files/usr/bin/login before executing shell.
##
